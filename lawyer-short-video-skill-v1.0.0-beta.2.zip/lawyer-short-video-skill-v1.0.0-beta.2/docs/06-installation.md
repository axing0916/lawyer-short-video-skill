# Codex Skill 安装指南

本仓库根目录本身是一个可安装 Skill 包。下载仓库与让 Codex 发现 Skill 是两个不同步骤。

## 推荐：使用 Skill Installer

在 Codex 中调用 `$skill-installer`，明确要求从以下仓库安装：

`https://github.com/axing0916/lawyer-short-video-skill`

安装完成后，通过 `/skills` 或输入 `$` 搜索 `lawyer-short-video`。若没有出现，重启 Codex 后再次检查。

## 仓库级使用

如果只想让某个项目使用本 Skill，将完整 Skill 文件夹放在目标项目的：

`$REPO_ROOT/.agents/skills/lawyer-short-video/`

该文件夹内必须直接包含 `SKILL.md`，同时保留本仓库的 `docs/`、`modules/`、`libraries/`、`templates/`、`config/`、`checklists/` 和 `agents/`。

不要只把 `SKILL.md` 单独复制进去，否则路由引用会失效。

## 用户级手工安装

如不使用 Installer，可将完整文件夹复制到：

`$HOME/.agents/skills/lawyer-short-video/`

这会让该用户的其他项目也能发现该 Skill。安装后同样通过 `/skills` 或 `$` 检查。

## 仅编辑仓库

在 Codex 中打开仓库根目录可以编辑、测试和维护项目，但根目录 `SKILL.md` 不属于文档所列的仓库级自动发现路径。此时应明确要求 Codex 读取该文件，或先按上述方法安装。

## 安装验证

成功安装后，用不含客户信息的虚构输入测试：

> 使用 `$lawyer-short-video`，先检查来源和脱敏状态，再判断是否可以进入文案生成。不要补造事实。

预期结果：Skill 先执行输入闸门，而不是直接生成案例故事。

参考：[OpenAI 官方 Build skills](https://learn.chatgpt.com/docs/build-skills)。
