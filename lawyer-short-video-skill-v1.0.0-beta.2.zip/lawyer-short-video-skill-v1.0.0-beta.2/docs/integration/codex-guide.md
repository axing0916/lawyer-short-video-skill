# Codex 集成

## 正确定位

Codex 可以把本地文件夹作为项目上下文，但“项目上下文”和“已发现的 Skill”不是同一概念。一个 Skill 通常由必需的 `SKILL.md` 以及可选的脚本、参考资料、资产和界面元数据组成。本仓库根目录是可安装 Skill 包；仅打开仓库不会自动完成安装。

官方说明：

- [Build skills](https://learn.chatgpt.com/docs/build-skills)
- [Projects and chats](https://learn.chatgpt.com/docs/projects)

## 本地使用

1. 按 [安装指南](../06-installation.md) 使用 `$skill-installer`，或把完整 Skill 放到规定目录；
2. 通过 `/skills` 或 `$` 确认 `lawyer-short-video` 已出现；
3. 在工作项目中准备已脱敏输入卡；
4. 显式调用 Skill，并要求先执行来源和脱敏检查；
5. 对文件改动先查看差异，再决定是否保存或提交。

示例请求：

> 使用 `$lawyer-short-video` 处理 `templates/input/content-brief.md` 的已填写副本。先检查脱敏和来源；通过后生成 60 秒收藏型干货口播。任何缺失事实标【待补充】，法律结论标出核验来源需求。只生成草稿，不要发布。

## GitHub 工作流

Codex 能否读写 GitHub 取决于本机 Git 凭据、GitHub 连接和仓库权限。推荐在独立分支提交并创建 Pull Request，不直接推送主分支。GitHub 集成不能替代分支保护、代码审查和秘密扫描。

## API Key 说明

本地打开项目和调用 Skill 不要求你把 API Key 写进配置。若另行开发调用 OpenAI API 的脚本，应使用环境变量或秘密管理服务，并遵守对应 API 文档；不要提交密钥。

## 能力边界

- 仓库规则不能自动证明法律结论正确；
- 未提供 Obsidian vault 路径和写权限时，不能自动保存到该 vault；
- 不会自动发布到短视频平台；
- 不应把生成的教学情景冒充真实案例。
