# GitHub 集成

## 推荐流程

1. 从最新 `main` 创建功能分支；
2. 本地生成或修改文件；
3. 运行仓库校验；
4. 检查差异中是否包含客户信息、凭据或未经授权材料；
5. 提交并创建 Pull Request；
6. 由维护者审核后合并。

## 私有与公开仓库

公开仓库中的所有提交历史都可能被复制。把私有仓库改为公开前，应检查整个 Git 历史，而不只是当前文件。若历史中出现过客户材料、密钥或个人信息，仅删除当前文件不够；需撤销凭据、评估历史清理和通知义务。

## 分支保护

建议为 `main` 启用 Pull Request 审核、状态检查和禁止强制推送。当前是否已经启用应在 GitHub 仓库设置中核实，不能仅凭本项目文档推断。

本仓库提供 `.github/workflows/validate.yml` 运行结构和行为校验。管理员仍需按 [GitHub 上线设置](github-settings.md) 手工启用 `main` 规则，并修正仓库 About 描述。

## 提交前检查

- `python3 tools/validate.py`
- 确认没有真实案号、人名、联系方式、密钥和内部路径
- 确认示例都标注为虚构教学情景
- 确认法律结论没有无来源断言
- 确认版本和日期一致

Codex 的 GitHub 使用说明可参考 OpenAI 官方的 [GitHub 与 Pull Request 指南](https://learn.chatgpt.com/docs/third-party/github)。
