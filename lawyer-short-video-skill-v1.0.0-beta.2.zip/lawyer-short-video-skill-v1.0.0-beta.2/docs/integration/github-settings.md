# GitHub 上线设置

这些设置不能通过上传普通文件自动完成，需要仓库管理员在 GitHub 界面操作。

## About 描述

建议替换为：

> 面向中国律师的短视频文案 Codex Skill：来源锁定、脱敏、内容生成、人工审核与复盘（Beta）

不要写“WorkBuddy 自动化”“自动发布”或“效果保证”；当前配置明确标记这些能力未实现。

## 主分支保护

在 `Settings → Rules → Rulesets` 中为 `main` 建立规则，至少要求：

- 通过 Pull Request 合并；
- `Validate skill` 状态检查通过；
- 禁止强制推送和删除分支；
- 重要变更至少一名维护者复核。

个人单维护者仓库可以暂不强制审批人数，但仍应保留 PR 和状态检查。

## Release

合并本修订后，待 GitHub Actions 通过，再创建预发布标签 `v1.0.0-beta.2`。Release 应标记为 Pre-release，并明确：法律内容仍需执业律师核验，第三方同步和平台发布未实现。

## Secrets

当前工作流不需要 Secrets。不要为了运行本地校验而添加 API Key、Cookie 或个人访问令牌。
