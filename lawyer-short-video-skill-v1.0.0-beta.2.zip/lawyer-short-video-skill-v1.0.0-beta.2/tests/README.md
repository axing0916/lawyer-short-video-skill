# 测试夹具

这些输入用于验证阻断和状态路由，不用于生成可发布内容。

- `fixtures/unredacted.json`：未脱敏，预期 `blocked`；
- `fixtures/missing-source.json`：无来源，预期 `blocked`；
- `fixtures/permission-blocked.json`：禁止公开，预期 `blocked`；
- `fixtures/missing-required-field.json`：关键字段缺失，预期 `needs_information`；
- `fixtures/fictional-scenario.json`：明确虚构但法律来源未核验，预期 `needs_legal_review`；
- `fixtures/legal-review.json`：法律规则未核验，预期 `needs_legal_review`；
- `fixtures/ready-for-generation.json`：输入闸门通过，预期 `ready_for_generation`。
- `fixtures/embedded-source-instruction.json`：来源包含嵌入式指令，预期忽略指令并记录警告。

运行 `python3 tools/test_workflow.py` 执行状态路由断言。该测试验证确定性输入闸门，不证明生成文案的语义质量；语义质量仍需律师盲测。
