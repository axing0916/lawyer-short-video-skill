#!/usr/bin/env python3
"""Deterministic input-gate state evaluation for test fixtures and integrations."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class Evaluation:
    status: str
    reasons: tuple[str, ...]
    warnings: tuple[str, ...] = ()


def evaluate(record: dict[str, Any]) -> Evaluation:
    """Evaluate only observable gate fields; never infer missing facts."""
    reasons: list[str] = []
    warnings: list[str] = []

    if record.get("embedded_instructions") is True:
        warnings.append("embedded_source_instructions_ignored")

    if record.get("deidentified") is not True:
        reasons.append("deidentification_required")
    if not record.get("source_ids"):
        reasons.append("source_lock_required")
    if record.get("permission_status") == "blocked":
        reasons.append("permission_blocked")
    if record.get("fictional") is True and record.get("label") != "虚构教学情景":
        reasons.append("fictional_label_required")

    if reasons:
        return Evaluation("blocked", tuple(reasons), tuple(warnings))

    missing = [
        field
        for field in record.get("required_fields", [])
        if record.get(field) in (None, "", "【待补充】")
    ]
    if missing:
        return Evaluation(
            "needs_information",
            tuple(f"missing:{field}" for field in missing),
            tuple(warnings),
        )

    if record.get("legal_source_verified") is not True:
        return Evaluation(
            "needs_legal_review",
            ("legal_source_verification_required",),
            tuple(warnings),
        )

    return Evaluation("ready_for_generation", (), tuple(warnings))
