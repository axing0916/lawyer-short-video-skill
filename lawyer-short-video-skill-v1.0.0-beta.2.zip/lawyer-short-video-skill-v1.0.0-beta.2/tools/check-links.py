#!/usr/bin/env python3
"""Check relative Markdown links and path-like inline code."""

from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LINK = re.compile(r"\[[^\]]+\]\(([^)]+)\)")
INLINE_CODE = re.compile(r"`([^`\n]+)`")
PATH_SUFFIXES = (".md", ".json", ".py", ".sh", ".yaml", ".yml")


def resolve_inline(path: Path, raw: str) -> Path | None:
    target = raw.strip().split("#", 1)[0]
    if (
        not target.endswith(PATH_SUFFIXES)
        or target in PATH_SUFFIXES
        or " " in target
        or target.startswith(("http://", "https://", "$", "{{"))
        or target.startswith(("YYYY-", "2026-"))
    ):
        return None

    candidates = [path.parent / target]
    if not target.startswith(("./", "../")):
        candidates.insert(0, ROOT / target)
    for candidate in candidates:
        if candidate.exists():
            return candidate.resolve()
    return candidates[0].resolve()


def main() -> int:
    failures: list[str] = []
    for path in ROOT.rglob("*.md"):
        text = path.read_text(encoding="utf-8")
        for raw in LINK.findall(text):
            target = raw.strip().split("#", 1)[0]
            if not target or target.startswith(("http://", "https://", "mailto:")):
                continue
            resolved = (path.parent / target).resolve()
            try:
                resolved.relative_to(ROOT)
            except ValueError:
                failures.append(f"link escapes repository: {path.relative_to(ROOT)} -> {raw}")
                continue
            if not resolved.exists():
                failures.append(f"missing link: {path.relative_to(ROOT)} -> {raw}")
        for raw in INLINE_CODE.findall(text):
            resolved = resolve_inline(path, raw)
            if resolved is None:
                continue
            try:
                resolved.relative_to(ROOT)
            except ValueError:
                failures.append(
                    f"inline path escapes repository: {path.relative_to(ROOT)} -> {raw}"
                )
                continue
            if not resolved.exists():
                failures.append(
                    f"missing inline path: {path.relative_to(ROOT)} -> {raw}"
                )
    if failures:
        print("\n".join(failures))
        return 1
    print("LINK CHECK PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
