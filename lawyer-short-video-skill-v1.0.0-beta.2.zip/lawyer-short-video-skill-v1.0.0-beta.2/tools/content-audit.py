#!/usr/bin/env python3
"""Check a small set of repository-wide factual and safety invariants."""

from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FORBIDDEN = {
    "support@lawyer-skill.com": "unverified support address",
    '"release_date": "2025-01-27"': "incorrect release date",
    '"status": "production"': "unverified production status",
    '"success_rate": 75': "fabricated success-rate setting",
}
SECRET_PATTERNS = {
    "AWS access key": re.compile(r"\bAKIA[0-9A-Z]{16}\b"),
    "GitHub token": re.compile(r"\bgh[pousr]_[A-Za-z0-9]{20,}\b"),
    "API secret": re.compile(r"\bsk-[A-Za-z0-9_-]{20,}\b"),
    "private key": re.compile(r"BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY"),
    "possible Chinese ID number": re.compile(r"(?<!\d)\d{17}[\dXx](?!\d)"),
    "possible Chinese mobile number": re.compile(r"(?<!\d)1[3-9]\d{9}(?!\d)"),
}
NETWORK_PATTERNS = {
    "curl command": re.compile(r"\bcurl\b"),
    "wget command": re.compile(r"\bwget\b"),
    "Python requests": re.compile(r"\brequests\."),
    "Python URL request": re.compile(r"\burllib\.request\b"),
    "raw socket": re.compile(r"\bsocket\."),
}


def main() -> int:
    failures: list[str] = []
    for path in ROOT.rglob("*"):
        if not path.is_file() or ".git" in path.parts or path.name == "content-audit.py":
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            continue
        for phrase, reason in FORBIDDEN.items():
            if phrase in text:
                failures.append(f"{path.relative_to(ROOT)}: {reason}")
        for label, pattern in SECRET_PATTERNS.items():
            if pattern.search(text):
                failures.append(f"{path.relative_to(ROOT)}: possible {label}")
        if path.suffix in {".py", ".sh"}:
            for label, pattern in NETWORK_PATTERNS.items():
                if pattern.search(text):
                    failures.append(
                        f"{path.relative_to(ROOT)}: undeclared network behavior ({label})"
                    )
    if failures:
        print("\n".join(failures))
        return 1
    print("CONTENT AUDIT PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
