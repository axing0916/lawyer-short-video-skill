#!/usr/bin/env python3
"""Run behavior assertions declared by tests/fixtures/*.json."""

from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))

from workflow_state import evaluate  # noqa: E402


def main() -> int:
    failures: list[str] = []
    fixtures = sorted((ROOT / "tests" / "fixtures").glob("*.json"))
    if not fixtures:
        print("no workflow fixtures found")
        return 1

    for path in fixtures:
        record = json.loads(path.read_text(encoding="utf-8"))
        result = evaluate(record)
        expected_status = record["expected_status"]
        if result.status != expected_status:
            failures.append(
                f"{path.name}: expected status {expected_status}, got {result.status}"
            )
        expected_reason = record.get("expected_reason")
        if expected_reason and expected_reason not in result.reasons:
            failures.append(
                f"{path.name}: expected reason {expected_reason}, got {result.reasons}"
            )
        expected_warning = record.get("expected_warning")
        if expected_warning and expected_warning not in result.warnings:
            failures.append(
                f"{path.name}: expected warning {expected_warning}, got {result.warnings}"
            )

    if failures:
        print("WORKFLOW TESTS FAILED")
        for failure in failures:
            print(f"- {failure}")
        return 1

    print(f"WORKFLOW TESTS PASSED: {len(fixtures)} fixtures")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
