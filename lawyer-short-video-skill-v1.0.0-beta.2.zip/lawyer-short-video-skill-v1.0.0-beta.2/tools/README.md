# 校验工具

工具只读取当前仓库，不访问网络、不上传内容、不修改用户文件。

- `validate.py`：总验收，不以文件总数作为通过条件；
- `check-links.py`：Markdown 链接和路径型内联代码；
- `count-content.py`：文件、字符和分类统计；
- `content-audit.py`：检查错误日期、虚假支持信息、常见密钥/个人号码模式和脚本网络行为；
- `workflow_state.py`：确定性输入闸门状态机；
- `test_workflow.py`：执行测试夹具中的状态和风险警告断言；
- `setup.sh`：运行环境与仓库校验；
- `version-check.sh`：版本真源一致性。
