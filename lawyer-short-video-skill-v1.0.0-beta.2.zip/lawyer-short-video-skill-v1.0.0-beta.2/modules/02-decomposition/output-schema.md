# 拆解输出

```yaml
content_id: LSV-0001
status: ready_for_generation
sources: []
facts: []
party_claims: []
timeline: []
legal_issues: []
evidence_gaps: []
privacy_risks: []
angles:
  - angle_id: ANG-01
    audience_problem: ""
    primary_objective: save
    content_type: practical
    source_claims: []
    legal_checks: []
blocked_reasons: []
```

`status` 只能是 `blocked`、`needs_information`、`ready_for_generation`。完整状态、中文标签和允许转换以 `config/workflow-states.json` 为唯一机器可读真源。
